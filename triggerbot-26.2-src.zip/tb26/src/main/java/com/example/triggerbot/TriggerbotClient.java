package com.example.triggerbot;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import org.lwjgl.glfw.GLFW;

public class TriggerbotClient implements ClientModInitializer {
    private static final KeyMapping.Category CATEGORY =
            KeyMapping.Category.register(Identifier.fromNamespaceAndPath("triggerbot", "main"));

    private static KeyMapping toggleKey;
    private static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        TriggerbotConfig.load();
        enabled = TriggerbotConfig.INSTANCE.enabledOnStart;

        toggleKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.triggerbot.toggle",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_P,
                CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(TriggerbotClient::onTick);
    }

    private static void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) {
            return;
        }

        while (toggleKey.consumeClick()) {
            enabled = !enabled;
            mc.gui.setOverlayMessage(
                    Component.literal("Triggerbot: ")
                            .append(Component.literal(enabled ? "ON" : "OFF")
                                    .withStyle(enabled ? ChatFormatting.GREEN : ChatFormatting.RED)),
                    false);
        }

        if (!enabled || mc.screen != null || mc.gameMode == null) {
            return;
        }

        if (!(mc.hitResult instanceof EntityHitResult hit)) {
            return;
        }

        TriggerbotConfig cfg = TriggerbotConfig.INSTANCE;

        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity living) || !living.isAlive()) {
            return;
        }
        if (target instanceof Player p) {
            if (p.isSpectator() || !cfg.attackPlayers) {
                return;
            }
        } else if (target instanceof Enemy) {
            if (!cfg.attackMonsters) {
                return;
            }
        } else if (!cfg.attackAnimals) {
            return;
        }

        if (cfg.requireItemInHand && mc.player.getMainHandItem().isEmpty()) {
            return;
        }

        if (mc.player.getAttackStrengthScale(0.5f) < cfg.minCooldown) {
            return;
        }

        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }
}
