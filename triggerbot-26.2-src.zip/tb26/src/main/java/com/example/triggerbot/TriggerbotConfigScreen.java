package com.example.triggerbot;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class TriggerbotConfigScreen extends Screen {
    private final Screen parent;

    public TriggerbotConfigScreen(Screen parent) {
        super(Component.literal("Triggerbot"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        TriggerbotConfig c = TriggerbotConfig.INSTANCE;
        int w = 220;
        int x = this.width / 2 - w / 2;
        int y = this.height / 2 - 80;
        int step = 24;

        addRenderableWidget(new CooldownSlider(x, y, w, 20, c.minCooldown));
        y += step;
        addToggle(x, y, w, "Включён при запуске", () -> c.enabledOnStart, v -> c.enabledOnStart = v);
        y += step;
        addToggle(x, y, w, "Бить игроков", () -> c.attackPlayers, v -> c.attackPlayers = v);
        y += step;
        addToggle(x, y, w, "Бить мобов (враждебных)", () -> c.attackMonsters, v -> c.attackMonsters = v);
        y += step;
        addToggle(x, y, w, "Бить животных и остальных", () -> c.attackAnimals, v -> c.attackAnimals = v);
        y += step;
        addToggle(x, y, w, "Только с предметом в руке", () -> c.requireItemInHand, v -> c.requireItemInHand = v);
        y += step + 8;

        addRenderableWidget(Button.builder(Component.literal("Готово"), b -> onClose())
                .bounds(x, y, w, 20).build());
    }

    private void addToggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        addRenderableWidget(Button.builder(toggleText(label, get.get()), b -> {
            set.accept(!get.get());
            b.setMessage(toggleText(label, get.get()));
            TriggerbotConfig.save();
        }).bounds(x, y, w, 20).build());
    }

    private static Component toggleText(String label, boolean value) {
        return Component.literal(label + ": " + (value ? "ВКЛ" : "ВЫКЛ"));
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float delta) {
        super.extractRenderState(graphics, mouseX, mouseY, delta);
        int tx = this.width / 2 - this.font.width(this.title) / 2;
        graphics.text(this.font, this.title, tx, this.height / 2 - 105, 0xFFFFFFFF, true);
    }

    @Override
    public void onClose() {
        TriggerbotConfig.save();
        this.minecraft.setScreen(parent);
    }

    /** Слайдер минимального заряда атаки: 50% - 100% */
    private static class CooldownSlider extends AbstractSliderButton {
        CooldownSlider(int x, int y, int w, int h, float current) {
            super(x, y, w, h, Component.empty(), (current - 0.5f) / 0.5f);
            updateMessage();
        }

        private float actual() {
            return 0.5f + (float) this.value * 0.5f;
        }

        @Override
        protected void updateMessage() {
            setMessage(Component.literal("Мин. заряд атаки: " + Math.round(actual() * 100) + "%"));
        }

        @Override
        protected void applyValue() {
            TriggerbotConfig.INSTANCE.minCooldown = actual();
            TriggerbotConfig.save();
        }
    }
}
