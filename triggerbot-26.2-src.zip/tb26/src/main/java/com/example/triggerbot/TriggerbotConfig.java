package com.example.triggerbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public class TriggerbotConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("triggerbot.json");

    public static TriggerbotConfig INSTANCE = new TriggerbotConfig();

    public boolean enabledOnStart = false;
    /** Минимальный заряд атаки 0.5 - 1.0 */
    public float minCooldown = 1.0f;
    public boolean attackPlayers = true;
    public boolean attackMonsters = true;
    public boolean attackAnimals = false;
    public boolean requireItemInHand = false;

    public static void load() {
        if (Files.exists(FILE)) {
            try (Reader r = Files.newBufferedReader(FILE)) {
                TriggerbotConfig loaded = GSON.fromJson(r, TriggerbotConfig.class);
                if (loaded != null) {
                    INSTANCE = loaded;
                }
            } catch (Exception e) {
                System.err.println("[Triggerbot] Не удалось прочитать конфиг: " + e);
            }
        }
        INSTANCE.minCooldown = Math.max(0.5f, Math.min(1.0f, INSTANCE.minCooldown));
        save();
    }

    public static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(INSTANCE, w);
        } catch (IOException e) {
            System.err.println("[Triggerbot] Не удалось сохранить конфиг: " + e);
        }
    }
}
